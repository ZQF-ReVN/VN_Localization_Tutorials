#pragma once
#include <string>


namespace Rut
{
	static constexpr uint32_t AutoMem_AutoSize = -1;
}

namespace Rut::RxStream
{


	class AutoMem
	{
	private:
		uint32_t m_szData;
		uint8_t* m_pData;

	public:
		AutoMem();
		AutoMem(const AutoMem& buffer);
		AutoMem(AutoMem&& buffer) noexcept;
		AutoMem(std::string_view wsFile);
		AutoMem(std::wstring_view wsFile);
		AutoMem(std::string_view msFile, uint32_t szFile);
		AutoMem(std::wstring_view wsFile, uint32_t szFile);
		~AutoMem();

		template <typename T_Ptr> operator T_Ptr* () { return (T_Ptr*)m_pData; }
		template <typename T_Type> operator T_Type () { return (T_Type)m_szData; }
		template <typename T_Size> AutoMem& operator[] (T_Size tSize) { SetSize(tSize); return *this; }

		uint8_t* SetSize(uint32_t szRes);
		uint32_t GetSize();
		uint8_t* GetPtr();

		void     SaveDataToFile(std::string_view msFile);
		void     SaveDataToFile(std::wstring_view wsFile);
		uint8_t* LoadFileViaSize(std::string_view msFile, uint32_t szFile = AutoMem_AutoSize);
		uint8_t* LoadFileViaSize(std::wstring_view wsFile, uint32_t szFile = AutoMem_AutoSize);
	};
}