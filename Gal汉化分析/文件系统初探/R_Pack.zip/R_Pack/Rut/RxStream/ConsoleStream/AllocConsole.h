#pragma once
#include <corecrt_wstdio.h>

namespace Rut::RxStream
{
	FILE* SetConsole(const wchar_t* lpTitle);
}