#pragma once
#include <string>
#include <stdexcept>
#include <Windows.h>

#include "BasicStream.h"


namespace Rut::RxStream
{
	class Binary : public BasicStream
	{
	public:
		Binary();
		Binary(const char* cpPath, RIO emAccess, RCO emCreate = RCO::RCO_AUTO);
		Binary(const wchar_t* wpPath, RIO emAccess, RCO emCreate = RCO::RCO_AUTO);
		Binary(std::string_view msPath, RIO emAccess, RCO emCreate = RCO::RCO_AUTO);
		Binary(std::wstring_view wsPath, RIO emAccess, RCO emCreate = RCO::RCO_AUTO);
		Binary(const Binary& refStream) = delete;
		~Binary();

		template <typename TYPE> operator TYPE() { TYPE tmp{ 0 }; Read((TYPE*)&tmp, sizeof(TYPE)); return tmp; }
		template <typename TYPE> Binary& operator >>(TYPE& tType) { Read((void*)&tType, sizeof(TYPE)); return *this; }
		template <typename TYPE> Binary& operator <<(TYPE& tType) { Write((void*)&tType, sizeof(tType)); return *this; }

	};

	void SaveFileViaPath(const char* cpPath, void* pData, uint32_t nBytes);
	void SaveFileViaPath(const wchar_t* wpPath, void* pData, uint32_t nBytes);
	void SaveFileViaPath(std::string_view msPath, void* pData, uint32_t nBytes);
	void SaveFileViaPath(std::wstring_view wsPath, void* pData, uint32_t nBytes);

	template <typename T_FileName>
	std::streamsize GetFileSize(const T_FileName& tFile)
	{
		std::ifstream ifs(tFile, std::ios::binary);
		if (!ifs) { throw std::runtime_error("GetFileSize: Open File Error!"); }

		ifs.seekg(0, std::ios::end);
		return ifs.tellg();
	}

	template <typename T_Stream>
	std::streamsize GetFileSize(T_Stream& tStream)
	{
		std::streamsize file_size = 0;
		std::streampos file_pos = tStream.tellg();

		tStream.seekg(0, std::ios::end);
		file_size = tStream.tellg();
		tStream.seekg(file_pos, std::ios::beg);

		return file_size;
	}
}