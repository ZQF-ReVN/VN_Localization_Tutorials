#pragma once

#include "RxStream/FileStream/TextStream.h"
#include "RxStream/FileStream/BinaryStream.h"

#include "RxStream/MemoryStream/AutoMem.h"

#include "RxStream/ConsoleStream/PutConsole.h"
#include "RxStream/ConsoleStream/AllocConsole.h"