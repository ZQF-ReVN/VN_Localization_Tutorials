#include <Windows.h>

#include "../../lib/Rxx/INI.h"
#include "../../lib/Rxx/File.h"
#include "../../lib/Rxx/Hook.h"

using namespace Rcf::INI;
using namespace Rut::FileX;
using namespace Rut::HookX;


static DWORD g_dwExeBase = NULL;
static DWORD g_dwDllBase = NULL;


char* SaveStrOnHeap(const std::string& msStr)
{
	char* pStr = new char[msStr.size() + 1];
	memcpy(pStr, msStr.c_str(), msStr.size() + 1);
	return pStr;
}

VOID StartHook()
{
	std::wstring dll_name_noext = PathRemoveExtension(GetModuleNameViaBaseW((uint32_t)g_dwDllBase));

	try
	{
		INI_File ini(dll_name_noext + L".ini");
		bool is_hook_font_a = ini[L"HookFont"][L"HookCreateFontA"];
		bool is_hook_font_indirect_a = ini[L"HookFont"][L"HookCreateFontIndirectA"];

		if (is_hook_font_a)
		{
			HookCreateFontA(ini[L"HookFont"][L"Charset"], SaveStrOnHeap(ini[L"HookFont"][L"FontName"]));
		}

		if (is_hook_font_indirect_a)
		{
			HookCreateFontIndirectA(ini[L"HookFont"][L"Charset"], SaveStrOnHeap(ini[L"HookFont"][L"FontName"]));
		}
	}
	catch (const std::runtime_error& err)
	{
		MessageBoxA(NULL, err.what(), "HookFont", NULL);
	}
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		g_dwExeBase = (DWORD)GetModuleHandleW(NULL);
		g_dwDllBase = (DWORD)hModule;
		StartHook();
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

extern "C" VOID __declspec(dllexport) Dir_A() {}